package com.example.beerapplication;

import java.util.ArrayList;
import java.util.List;

import kotlin.contracts.Returns;

public class BeerExpert
{
    List<String> BeerExpert(String BeerColor)
    {
        List<String> BeerSet=new ArrayList<>();
        if(BeerColor.equals("Larger"))
        {
            BeerSet.add("Lion Larger");
        }
        else if(BeerColor.equals("Stout"))
        {
            BeerSet.add("Stout Beer");
        }
        else if(BeerColor.equals("Ale"))
        {
            BeerSet.add("Ale Beer");
        }
        else if(BeerColor.equals("Brown Ale"))
        {
            BeerSet.add("Brown Ale Beer");
        }
        else
        {
            BeerSet.add("Please Select A Beer Type");
        }
        return  BeerSet;
    }
}
