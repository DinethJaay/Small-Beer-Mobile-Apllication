package com.example.beerapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    BeerExpert expert=new BeerExpert();
    public void onClickFindBeer(View view)
    {
        TextView TextView=findViewById(R.id.txtViewName);
        Spinner spinner =findViewById(R.id.spinner);
        String select_color=String.valueOf(spinner.getSelectedItem());
        List<String> return_beer_set=expert.BeerExpert(select_color);
        StringBuilder final_Beer_set=new StringBuilder();
        for(String beer : return_beer_set)
        {
            final_Beer_set.append(beer+"\n");
        }
        TextView.setText(final_Beer_set);
}
}